import { chartData, timelineData, mapData } from './data.js';
import { renderCharts, renderTimeline, renderMap, initAccordions } from './interactive_elements.js';

document.addEventListener('DOMContentLoaded', async () => {
    const contentEl = document.getElementById('report-content');
    const navMenu = document.getElementById('navigation-menu');
    const loadingOverlay = document.getElementById('loading-overlay');
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');

    try {
        const response = await fetch('report.md');
        const markdown = await response.text();
        contentEl.innerHTML = marked.parse(markdown);


        const headings = contentEl.querySelectorAll('h2');
        headings.forEach(heading => {
            const id = heading.textContent.toLowerCase().replace(/\s+/g, '-');
            heading.id = id;
            const link = document.createElement('a');
            link.href = `#${id}`;
            link.textContent = heading.textContent;
            navMenu.appendChild(link);
        });


        renderCharts(chartData);
        renderTimeline(timelineData);
        renderMap(mapData);
        initAccordions();

        lucide.createIcons();
        setupScrollSpy();
        setupMobileMenu();
        
    } catch (error) {
        console.error('Error loading report:', error);
        contentEl.innerHTML = '<p class="text-red-500">Failed to load the report. Please try again later.</p>';
    } finally {

        loadingOverlay.classList.add('opacity-0');
        setTimeout(() => loadingOverlay.style.display = 'none', 500);
    }
});

function setupScrollSpy() {
    const navLinks = document.querySelectorAll('#navigation-menu a');
    const sections = Array.from(navLinks).map(link => {
        const id = link.getAttribute('href').substring(1);
        return document.getElementById(id);
    });

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                navLinks.forEach(link => {
                    link.classList.toggle('active', link.getAttribute('href').substring(1) === entry.target.id);
                });
            }
        });
    }, { rootMargin: "-50% 0px -50% 0px", threshold: 0 });

    sections.forEach(section => {
        if(section) observer.observe(section);
    });
}

function setupMobileMenu() {
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('main');

    mobileMenuButton.addEventListener('click', (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('hidden');
        sidebar.classList.toggle('fixed');
        sidebar.classList.toggle('w-full');
        sidebar.classList.toggle('h-full');
        sidebar.classList.toggle('z-30');
    });

    mainContent.addEventListener('click', () => {
        if (!sidebar.classList.contains('hidden')) {
            sidebar.classList.add('hidden');
            sidebar.classList.remove('fixed', 'w-full', 'h-full', 'z-30');
        }
    });
}
