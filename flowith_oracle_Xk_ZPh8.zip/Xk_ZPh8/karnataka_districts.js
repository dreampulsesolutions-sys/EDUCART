export const karnatakaDistricts = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": { "district": "Bagalkot" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.567, 16.632 ], [ 75.94, 16.63 ], [ 76.241, 16.353 ], [ 76.28, 16.035 ], [ 75.952, 15.86 ], [ 75.46, 15.891 ], [ 75.247, 16.142 ], [ 75.567, 16.632 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Ballari" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.55, 15.75 ], [ 76.91, 15.75 ], [ 77.29, 15.3 ], [ 77.08, 15.1 ], [ 76.8, 14.7 ], [ 76.35, 14.8 ], [ 75.9, 15.15 ], [ 76.15, 15.45 ], [ 76.55, 15.75 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Belagavi" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.3, 16.8 ], [ 75.0, 16.8 ], [ 75.3, 16.5 ], [ 75.2, 16.1 ], [ 74.8, 15.7 ], [ 74.3, 15.5 ], [ 74.1, 15.8 ], [ 74.05, 16.2 ], [ 74.3, 16.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Bengaluru Rural" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 77.4, 13.4 ], [ 77.7, 13.3 ], [ 77.8, 13.0 ], [ 77.5, 12.8 ], [ 77.2, 13.1 ], [ 77.4, 13.4 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Bengaluru Urban" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 77.5, 13.15 ], [ 77.75, 13.1 ], [ 77.7, 12.85 ], [ 77.45, 12.9 ], [ 77.5, 13.15 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Bidar" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 77.1, 18.5 ], [ 77.5, 18.5 ], [ 77.9, 18.2 ], [ 77.8, 17.8 ], [ 77.3, 17.6 ], [ 77.0, 17.9 ], [ 77.1, 18.5 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Chamarajanagar" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.3, 12.2 ], [ 77.0, 12.2 ], [ 77.7, 11.9 ], [ 77.5, 11.5 ], [ 76.8, 11.4 ], [ 76.3, 11.7 ], [ 76.3, 12.2 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Chikkaballapur" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 77.7, 13.7 ], [ 78.0, 13.7 ], [ 78.2, 13.4 ], [ 77.8, 13.2 ], [ 77.5, 13.5 ], [ 77.7, 13.7 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Chikkamagaluru" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.1, 13.7 ], [ 75.8, 13.8 ], [ 76.1, 13.5 ], [ 75.9, 13.0 ], [ 75.4, 12.9 ], [ 75.0, 13.2 ], [ 75.1, 13.7 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Chitradurga" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.2, 14.8 ], [ 76.8, 14.7 ], [ 77.0, 14.3 ], [ 76.7, 13.9 ], [ 76.2, 13.8 ], [ 76.0, 14.3 ], [ 76.2, 14.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Dakshina Kannada" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.8, 13.2 ], [ 75.4, 13.1 ], [ 75.5, 12.7 ], [ 75.2, 12.5 ], [ 74.7, 12.8 ], [ 74.8, 13.2 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Davanagere" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.7, 14.8 ], [ 76.2, 14.8 ], [ 76.3, 14.4 ], [ 75.9, 14.0 ], [ 75.6, 14.2 ], [ 75.7, 14.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Dharwad" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.8, 15.7 ], [ 75.4, 15.7 ], [ 75.5, 15.3 ], [ 75.0, 15.1 ], [ 74.7, 15.3 ], [ 74.8, 15.7 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Gadag" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.4, 15.8 ], [ 75.9, 15.8 ], [ 76.1, 15.5 ], [ 75.6, 15.2 ], [ 75.3, 15.4 ], [ 75.4, 15.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Hassan" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.6, 13.3 ], [ 76.3, 13.3 ], [ 76.4, 12.9 ], [ 75.8, 12.7 ], [ 75.5, 13.0 ], [ 75.6, 13.3 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Haveri" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.0, 15.1 ], [ 75.6, 15.1 ], [ 75.7, 14.7 ], [ 75.2, 14.5 ], [ 75.0, 14.8 ], [ 75.0, 15.1 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Kalaburagi" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.5, 17.8 ], [ 77.3, 17.7 ], [ 77.4, 17.2 ], [ 76.8, 16.8 ], [ 76.2, 17.0 ], [ 76.5, 17.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Kodagu" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.4, 12.7 ], [ 76.0, 12.7 ], [ 76.1, 12.3 ], [ 75.6, 12.2 ], [ 75.3, 12.5 ], [ 75.4, 12.7 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Kolar" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 78.1, 13.4 ], [ 78.4, 13.3 ], [ 78.3, 13.0 ], [ 78.0, 13.1 ], [ 78.1, 13.4 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Koppal" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.9, 15.8 ], [ 76.5, 15.7 ], [ 76.6, 15.3 ], [ 76.1, 15.2 ], [ 75.8, 15.5 ], [ 75.9, 15.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Mandya" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.5, 12.8 ], [ 77.2, 12.7 ], [ 77.1, 12.3 ], [ 76.6, 12.2 ], [ 76.4, 12.5 ], [ 76.5, 12.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Mysuru" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.0, 12.5 ], [ 76.8, 12.4 ], [ 77.0, 12.0 ], [ 76.5, 11.8 ], [ 75.9, 12.1 ], [ 76.0, 12.5 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Raichur" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.5, 16.5 ], [ 77.3, 16.3 ], [ 77.2, 15.9 ], [ 76.6, 15.8 ], [ 76.2, 16.1 ], [ 76.5, 16.5 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Ramanagara" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 77.1, 12.9 ], [ 77.5, 12.8 ], [ 77.4, 12.6 ], [ 77.0, 12.7 ], [ 77.1, 12.9 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Shivamogga" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.8, 14.5 ], [ 75.7, 14.5 ], [ 75.8, 14.0 ], [ 75.2, 13.7 ], [ 74.7, 14.0 ], [ 74.8, 14.5 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Tumakuru" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.5, 14.0 ], [ 77.3, 13.8 ], [ 77.4, 13.3 ], [ 76.8, 13.1 ], [ 76.4, 13.5 ], [ 76.5, 14.0 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Udupi" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.6, 13.8 ], [ 75.1, 13.8 ], [ 75.2, 13.4 ], [ 74.7, 13.2 ], [ 74.5, 13.5 ], [ 74.6, 13.8 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Uttara Kannada" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 74.2, 15.5 ], [ 74.9, 15.3 ], [ 75.0, 14.7 ], [ 74.5, 14.0 ], [ 74.1, 14.5 ], [ 74.2, 15.5 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Vijayapura" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 75.5, 17.3 ], [ 76.3, 17.2 ], [ 76.5, 16.7 ], [ 75.8, 16.5 ], [ 75.3, 16.8 ], [ 75.5, 17.3 ] ] ] }
        },
        {
            "type": "Feature",
            "properties": { "district": "Yadgir" },
            "geometry": { "type": "Polygon", "coordinates": [ [ [ 76.8, 17.0 ], [ 77.4, 16.9 ], [ 77.3, 16.5 ], [ 76.7, 16.4 ], [ 76.8, 17.0 ] ] ] }
        }
    ]
};
