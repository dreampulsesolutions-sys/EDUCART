export const chartData = {
    demographics: {
        labels: ['Lingayats', 'Vokkaligas', 'Scheduled Castes', 'Muslims', 'Scheduled Tribes', 'Christians', 'Others'],
        data: [17, 15, 19.5, 13, 5, 1.9, 28.6]
    },
    election2023: {
        labels: ['Congress (INC)', 'BJP', 'JD(S)', 'Others'],
        data: [135, 66, 19, 4]
    }
};

export const timelineData = [
    { year: '12th C', title: 'Basavanna & Lingayatism', description: 'Basavanna leads a socio-religious reform, establishing Lingayatism which challenges the caste system and Vedic rituals.' },
    { year: '1890', title: 'Kannada Unification Movement', description: 'The Karnataka Vidyavardhaka Sangha is formed, marking the start of the Kannada Ekikarana (unification) movement.' },
    { year: '1919', title: 'Miller Committee Report', description: 'The princely state of Mysore accepts the Miller Committee report, institutionalizing reservations for non-Brahmin backward classes.' },
    { year: '1956', title: 'State Reorganization', description: 'The unified Mysore State (later Karnataka) is formed, integrating Kannada-speaking regions.' },
    { year: '1970s', title: 'AHINDA Coalition', description: 'Chief Minister Devaraj Urs empowers minorities, backward classes, and Dalits (AHINDA), challenging the dominant caste hegemony.' },
    { year: '1977', title: 'Dalit Sangharsh Samiti (DSS)', description: 'The DSS is established, spearheading Dalit activism and advocating for rights and political mobilization.' },
    { year: '1980s', title: 'Gokak Agitation', description: 'A massive linguistic movement secures primary status for the Kannada language in education.' },
    { year: '1990s', title: 'Rise of BJP', description: 'The BJP gains prominence, consolidating the Lingayat vote bank and leveraging the Hindutva narrative.' },
    { year: '2018', title: 'Lingayat Status Bid', description: 'The Congress government recommends minority religion status for Lingayats, a controversial move ahead of elections.' },
    { year: '2023', title: 'Congress Landslide', description: 'Congress returns to power with a decisive majority, leveraging welfare schemes and a broad social coalition.' }
];

export const mapData = {
    'Bagalkot': { dominant_caste: 'Lingayat', info: 'Stronghold of Lingayat politics, consistently influencing BJP\'s performance.' },
    'Ballari': { dominant_caste: 'Mixed/ST', info: 'Region with significant ST population (Valmiki Nayaka), key for reservation politics.' },
    'Belagavi': { dominant_caste: 'Lingayat', info: 'A major political hub in North Karnataka with strong Marathi influence and a center for Lingayat mobilization.' },
    'Bengaluru Rural': { dominant_caste: 'Vokkaliga', info: 'Part of the Vokkaliga heartland, crucial for both JD(S) and Congress.' },
    'Bengaluru Urban': { dominant_caste: 'Mixed', info: 'A cosmopolitan hub where class, development, and language politics often intersect with caste.' },
    'Bidar': { dominant_caste: 'Lingayat/Muslim', info: 'Located in Kalyana-Karnataka, shows a mix of Lingayat influence and significant Muslim population.' },
    'Chamarajanagar': { dominant_caste: 'SC/Vokkaliga', info: 'High concentration of Scheduled Castes, a key area for AHINDA politics.' },
    'Chikkaballapur': { dominant_caste: 'Vokkaliga', info: 'Part of the Old Mysore region with strong Vokkaliga presence.' },
    'Chikkamagaluru': { dominant_caste: 'Vokkaliga/Lingayat', info: 'Known for its coffee plantations and a mix of dominant caste influences.' },
    'Chitradurga': { dominant_caste: 'SC/ST/Lingayat', info: 'Diverse population with a strong presence of SC/ST communities.' },
    'Dakshina Kannada': { dominant_caste: 'Bunt/Billava', info: 'A laboratory for Hindutva politics, with significant religious polarization.' },
    'Davanagere': { dominant_caste: 'Lingayat', info: 'Considered the center of Karnataka, with a strong Lingayat political base.' },
    'Dharwad': { dominant_caste: 'Lingayat', info: 'An educational and cultural hub of North Karnataka, central to the unification movement.' },
    'Gadag': { dominant_caste: 'Lingayat', info: 'Part of the core Lingayat belt in North Karnataka.' },
    'Hassan': { dominant_caste: 'Vokkaliga', info: 'The home district of the Deve Gowda family and a bastion for the JD(S).' },
    'Haveri': { dominant_caste: 'Lingayat', info: 'Another key district in the Lingayat-dominated political landscape.' },
    'Kalaburagi': { dominant_caste: 'Lingayat/SC', info: 'Heart of the Kalyana-Karnataka region, with high SC population and developmental focus.' },
    'Kodagu': { dominant_caste: 'Kodava/Vokkaliga', info: 'A unique region with a distinct Kodava identity and occasional demands for autonomy.' },
    'Kolar': { dominant_caste: 'Vokkaliga/SC', info: 'Known for its mix of Vokkaliga and Dalit populations, influencing AHINDA strategies.' },
    'Koppal': { dominant_caste: 'Lingayat/Kuruba', info: 'An area with a blend of dominant and backward class influences.' },
    'Mandya': { dominant_caste: 'Vokkaliga', info: 'The epicenter of Vokkaliga politics and a traditional stronghold of the JD(S).' },
    'Mysuru': { dominant_caste: 'Vokkaliga', info: 'The cultural capital and a key part of the Old Mysore region, dominated by Vokkaliga politics.' },
    'Raichur': { dominant_caste: 'Lingayat/ST', info: 'A district in Kalyana-Karnataka with significant developmental challenges and ST population.' },
    'Ramanagara': { dominant_caste: 'Vokkaliga', info: 'Another core Vokkaliga district, important for both JD(S) and Congress.' },
    'Shivamogga': { dominant_caste: 'Lingayat/Idiga', info: 'Home district of B.S. Yediyurappa, reflecting strong Lingayat and BJP influence.' },
    'Tumakuru': { dominant_caste: 'Vokkaliga/Lingayat', info: 'A district with a mix of both dominant communities, making it a political battleground.' },
    'Udupi': { dominant_caste: 'Bunt/Billava', info: 'Coastal district known for its strong Hindutva politics and educational institutions.' },
    'Uttara Kannada': { dominant_caste: 'Mixed', info: 'Coastal region with diverse communities and significant environmental concerns influencing politics.' },
    'Vijayapura': { dominant_caste: 'Lingayat', info: 'Historic city and a major center for Lingayat political power in North Karnataka.' },
    'Yadgir': { dominant_caste: 'Lingayat/SC', info: 'Part of the underdeveloped Kalyana-Karnataka region, facing developmental issues.' }
};
