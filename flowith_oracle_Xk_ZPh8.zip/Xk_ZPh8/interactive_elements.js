import { karnatakaDistricts } from './karnataka_districts.js';


export function renderCharts(chartData) {
    const chartPlaceholder = document.querySelector('[data-chart="demographics"]');
    if (chartPlaceholder) {
        const canvas = document.createElement('canvas');
        chartPlaceholder.parentNode.replaceChild(canvas, chartPlaceholder);
        new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: chartData.demographics.labels,
                datasets: [{
                    label: 'Demographic Distribution',
                    data: chartData.demographics.data,
                    backgroundColor: ['#023e8a', '#0077b6', '#0096c7', '#00b4d8', '#48cae4', '#90e0ef', '#ade8f4'],
                    borderColor: '#ffffff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    title: {
                        display: true,
                        text: 'Karnataka: Estimated Community Distribution',
                        font: { size: 16, family: 'Open Sans' },
                        padding: { top: 10, bottom: 20 }
                    }
                }
            }
        });
    }

    const electionPlaceholder = document.querySelector('[data-chart="election2023"]');

}



export function renderTimeline(timelineData) {
    const placeholder = document.querySelector('[data-timeline="history"]');
    if (!placeholder) return;

    const container = document.createElement('div');
    container.id = 'timeline-container';
    const timelineEl = document.createElement('div');
    timelineEl.id = 'timeline';
    container.appendChild(timelineEl);
    
    timelineData.forEach(event => {
        const eventDiv = document.createElement('div');
        eventDiv.className = 'timeline-event';

        eventDiv.innerHTML = `
            <div class="timeline-marker"></div>
            <div class="timeline-year">${event.year}</div>
            <div class="timeline-title">${event.title}</div>
        `;

        eventDiv.addEventListener('click', () => showTimelineModal(event));
        timelineEl.appendChild(eventDiv);
    });

    placeholder.parentNode.replaceChild(container, placeholder);


    const modalHTML = `
        <div id="timeline-modal" class="modal" role="dialog" aria-modal="true">
            <div class="modal-content">
                <h3 id="modal-title" class="text-2xl font-bold mb-2"></h3>
                <p id="modal-description" class="text-gray-600"></p>
                <button id="modal-close" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800">
                    <i data-lucide="x"></i>
                </button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    lucide.createIcons();

    const modal = document.getElementById('timeline-modal');
    document.getElementById('modal-close').addEventListener('click', () => modal.classList.remove('show'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    });
}

function showTimelineModal(event) {
    document.getElementById('modal-title').textContent = `${event.year}: ${event.title}`;
    document.getElementById('modal-description').textContent = event.description;
    document.getElementById('timeline-modal').classList.add('show');
}



export function renderMap(mapData) {
    const placeholder = document.querySelector('[data-map="regional_divide"]');
    if (!placeholder) return;

    const mapDiv = document.createElement('div');
    mapDiv.id = 'leaflet-map';
    mapDiv.style.height = '500px';
    mapDiv.style.width = '100%';
    mapDiv.style.borderRadius = '12px';
    mapDiv.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
    placeholder.parentNode.replaceChild(mapDiv, placeholder);

    const map = L.map('leaflet-map').setView([14.5, 76.0], 6.5);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(map);

    function style(feature) {
        const northKarnataka = ['Bagalkot', 'Ballari', 'Belagavi', 'Bidar', 'Dharwad', 'Gadag', 'Haveri', 'Kalaburagi', 'Koppal', 'Raichur', 'Vijayapura', 'Yadgir', 'Uttara Kannada'];
        const isNorth = northKarnataka.includes(feature.properties.district);
        return {
            fillColor: isNorth ? '#0077b6' : '#4caf50',
            weight: 1,
            opacity: 1,
            color: 'white',
            dashArray: '3',
            fillOpacity: 0.6
        };
    }

    function onEachFeature(feature, layer) {
        const districtName = feature.properties.district;
        const data = mapData[districtName];
        let popupContent = `<h4 class="font-bold text-lg">${districtName}</h4>`;
        if (data) {
            popupContent += `<p class="text-sm"><b>Dominant Caste/Group:</b> ${data.dominant_caste}</p>`;
            popupContent += `<p class="text-sm mt-1">${data.info}</p>`;
        } else {
             popupContent += `<p class="text-sm">No specific data available.</p>`;
        }
        layer.bindPopup(popupContent);

        layer.on({
            mouseover: (e) => e.target.setStyle({ fillOpacity: 0.9 }),
            mouseout: (e) => geojson.resetStyle(e.target)
        });
    }

    const geojson = L.geoJSON(karnatakaDistricts, {
        style: style,
        onEachFeature: onEachFeature
    }).addTo(map);
}



export function initAccordions() {
    const headers = document.querySelectorAll('.prose h3');
    headers.forEach(header => {
        let content = header.nextElementSibling;
        let contents = [];
        while (content && content.tagName !== 'H2' && content.tagName !== 'H3') {
            contents.push(content);
            content = content.nextElementSibling;
        }

        if (contents.length > 0) {
            const wrapper = document.createElement('div');
            wrapper.className = 'accordion-content';
            contents.forEach(el => wrapper.appendChild(el));
            header.parentNode.insertBefore(wrapper, header.nextElementSibling);

            header.classList.add('accordion-header');
            const icon = document.createElement('i');
            icon.setAttribute('data-lucide', 'chevron-down');
            icon.className = 'transition-transform duration-300';
            header.appendChild(icon);

            header.addEventListener('click', () => {
                wrapper.classList.toggle('open');
                icon.classList.toggle('rotate-180');
            });
        }
    });
    lucide.createIcons();
}
